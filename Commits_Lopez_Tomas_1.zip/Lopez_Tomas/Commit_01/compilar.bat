@echo off
REM Compilacion en Windows (MinGW / gcc en el PATH) sin necesidad de make
gcc -Wall -Wextra -std=c99 -pedantic -O2 -o orion_tli.exe main.c artemis.c incisos.c mision.c validaciones.c -lm
if errorlevel 1 (
  echo Hubo errores de compilacion.
  pause
  exit /b 1
)
echo Compilado: orion_tli.exe
orion_tli.exe
pause
